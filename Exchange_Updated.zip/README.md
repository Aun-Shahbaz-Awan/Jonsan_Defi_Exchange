This is a [Next.js](https://nextjs.org/) App.

## Getting Started

First, install node modules:

npm install

# or

yarn install

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Machine Spacs

Node Version => v16.13.0
NPM Version => v8.1.0
Yarn Version => v1.22.17
