/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  env: {
    Telegram_Bot_Id: "5714394714:AAEe922U3cm-FboZ_6vcybTkKY6SQfY57v8",
    Telegram_CF_Bot_Id: "5705804281:AAGOJ0GTcY_DFkRaELTh3eA2_vR0vQPz8HA",
    Telegram_NL_Bot_Id:
      "5666742208:AAESJuebnJzD1HCyTqen4bhiUt-xW2xlB18",
    Old_Id: "5680126171",
    Chat_Id: "368459143",
  },
};

module.exports = nextConfig;
