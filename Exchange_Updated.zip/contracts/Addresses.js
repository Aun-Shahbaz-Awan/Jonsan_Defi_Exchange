// export const BSC_GUSD_Address = "0x3B68539325D0E1a15DF5aEE3E7045294eAe8d53B";
// export const BSC_TESTBNB_Address = "0xA02A8eccD43bEa3C77Df2a8882a5a99F0eB01c6e";
// export const BSC_TESTETH_Address = "0x1bcd21eA3BD9673010C1854e860c4813c7447F13";
// export const BSC_Exchange_Address = "0x802304d9715f2e49878d151cf51b0a6e3b04f5c3";
// Goerli Testnet
export const GUSD_Address = "0x94CBd329BDEC2C0bd4c2ace4e5EC3896f82FDe4C";
export const TESTBTC_Address = "0xDba17fF79fC903Fab8892133E18515eDeFD4D31e";
export const TESTETH_Address = "0x1bcd21eA3BD9673010C1854e860c4813c7447F13";
export const Exchange_Address = "0xEf25A0452aE11C41CB078FE7728acBBC30a371c0";
